import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Modal, Button } from 'react-bootstrap'; // Import Modal and Button from react-bootstrap
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import './NavbarStu.css';

function NavbarClg() {
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [loading,setLoading]=useState(false);
  const { logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    setLoading(true);
    logout();
    navigate("/");
    setShowLogoutModal(false);
    setLoading(false);
  };
  return (

    <div>
    <nav className="navbar fixed-top navbar-expand-lg">
      <div className="container-fluid my-0.5">
        <Link className="navbar-brand" to="/College">
          {/* Your SVG code */}
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbar-pages"
          aria-controls="navbar-pages"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="navbar-pages">
          <ul className="navbar-nav ml-auto">
            <li className="nav-item">
              <Link className="nav-link active" to="/College">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/StudentList">
                StudentList
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/queries">
               queries
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/">
              <button
                type="button"
                className="btn btn-danger btn-lg"
                id="logout"
                onClick={(e) => {
                  e.preventDefault();
                  setShowLogoutModal(true)}}
              >
                {" "}
                Log Out {" "}
              </button>
              </Link>
            </li>
          </ul>
        </div>
      </div>
      </nav>

      {showLogoutModal && (
        <Modal show={showLogoutModal} onHide={() => setShowLogoutModal(false)}>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Logout</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            Are you sure you want to log out? You will be redirected to the home
            page.
          </Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={() => setShowLogoutModal(false)}
            >
              Cancel
            </Button>
            <Button
              variant="danger"
              onClick={() => handleLogout()}
            >
              Logout
            </Button>
            
          </Modal.Footer>
        </Modal>
      )}

      </div>
    
  );
}

export default NavbarClg;
